# microservice-security
The first commit contains a demo of how to consume the UAA and Google OpenID Connect as identity providers

The rest of the commits outline how to create, secure, and test the security of microservices, one step at a time.
